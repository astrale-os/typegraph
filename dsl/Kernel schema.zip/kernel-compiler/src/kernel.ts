// src/kernel.ts
// ============================================================
// The Kernel Prelude — Embedded
//
// This string is parsed by the compiler at startup before any
// user schema. It defines the meta-model: the types and edges
// that the type system itself is built from.
//
// Builtin scalar types (String, Int, Float, Boolean, Timestamp,
// Bitmask, ByteString) are NOT declared here. They are injected
// into the primal scope by the compiler before this source is
// parsed. See the bootstrapping sequence in ARCHITECTURE-v3.md.
// ============================================================

export const KERNEL_SOURCE = `\
-- kernel.krl — The Kernel Prelude

-- Root Abstractions
interface Node {}

interface Link {}

-- Meta-Model
class Class: Node {}

class Interface: Node {}

-- Structural Edges
class has_parent(child: Node, parent: Node) [
  no_self,
  acyclic,
  child -> 0..1
]

class instance_of(instance: Node | Link, type: Class) [
  instance -> 1
]

class has_link(source: Node, link: Link) [
  link -> 1
]

class links_to(link: Link, target: Node) [
  link -> 1
]

-- Type System Edges
class implements(class: Class, interface: Interface) [
  no_self
]

class extends(child: Interface, parent: Interface) [
  no_self,
  acyclic
]

-- Permission Edges
interface Identity: Node {}

class has_perm(identity: Identity, target: Node) {
  perm: Bitmask
}

class excluded_from(subject: Identity, excluded: Identity) [
  no_self,
  acyclic
]

class constrained_by(subject: Identity, constraint: Identity) [
  no_self,
  acyclic
]

class extends_with(subject: Identity, extension: Identity) [
  no_self,
  acyclic
]
`;

/**
 * Builtin scalar types. These are injected into the primal scope
 * before the kernel prelude is parsed. They are the only "magic"
 * in the compiler — everything else derives from source.
 */
export const BUILTIN_SCALARS = [
  "String",
  "Int",
  "Float",
  "Boolean",
  "Timestamp",
  "Bitmask",
  "ByteString",
] as const;

export type BuiltinScalar = typeof BUILTIN_SCALARS[number];
