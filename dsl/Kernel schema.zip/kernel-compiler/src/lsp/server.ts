// src/lsp/server.ts
// ============================================================
// Language Server — stdio Transport
//
// Full LSP implementation for .krl files:
//   ✓ Diagnostics (on open / change / save)
//   ✓ Hover (type signatures + constraints)
//   ✓ Go-to-Definition
//   ✓ Completion (context-aware)
//   ✓ Document Symbols (outline)
//   ✓ Semantic Tokens (full)
// ============================================================

import {
  createConnection,
  ProposedFeatures,
  TextDocumentSyncKind,
  InitializeResult,
} from "vscode-languageserver/node.js";
import { TextDocument } from "vscode-languageserver-textdocument";
import { Workspace } from "./workspace.js";
import { provideHover } from "./hover.js";
import { provideDefinition } from "./definition.js";
import { provideCompletion } from "./completion.js";
import { provideDocumentSymbols } from "./symbols.js";
import {
  provideSemanticTokens,
  SEMANTIC_TOKEN_TYPES,
  SEMANTIC_TOKEN_MODIFIERS,
} from "./semantic-tokens.js";

export function startServer(): void {
  // Force stdio transport regardless of argv
  const connection = createConnection(ProposedFeatures.all, process.stdin, process.stdout);
  const workspace = new Workspace();

  // ─── Initialize ────────────────────────────────────────────

  connection.onInitialize((): InitializeResult => {
    return {
      capabilities: {
        textDocumentSync: TextDocumentSyncKind.Full,

        hoverProvider: true,

        definitionProvider: true,

        completionProvider: {
          triggerCharacters: [":", "[", "=", "<", "|", ",", " "],
          resolveProvider: false,
        },

        documentSymbolProvider: true,

        semanticTokensProvider: {
          legend: {
            tokenTypes: [...SEMANTIC_TOKEN_TYPES],
            tokenModifiers: [...SEMANTIC_TOKEN_MODIFIERS],
          },
          full: true,
        },
      },
    };
  });

  // ─── Document Lifecycle ────────────────────────────────────

  connection.onDidOpenTextDocument((params) => {
    const { uri, text, version } = params.textDocument;
    const diagnostics = workspace.update(uri, text, version);
    connection.sendDiagnostics({ uri, diagnostics });
  });

  connection.onDidChangeTextDocument((params) => {
    const { uri, version } = params.textDocument;
    // Full sync — contentChanges[0] has the entire text
    const text = params.contentChanges[0]?.text;
    if (text == null) return;
    const diagnostics = workspace.update(uri, text, version);
    connection.sendDiagnostics({ uri, diagnostics });
  });

  connection.onDidCloseTextDocument((params) => {
    workspace.remove(params.textDocument.uri);
    // Clear diagnostics
    connection.sendDiagnostics({ uri: params.textDocument.uri, diagnostics: [] });
  });

  // ─── Hover ─────────────────────────────────────────────────

  connection.onHover((params) => {
    const state = workspace.get(params.textDocument.uri);
    if (!state) return null;

    const offset = state.lineMap.offsetAt(
      params.position.line,
      params.position.character,
    );

    return provideHover(workspace, state, offset);
  });

  // ─── Definition ────────────────────────────────────────────

  connection.onDefinition((params) => {
    const state = workspace.get(params.textDocument.uri);
    if (!state) return null;

    const offset = state.lineMap.offsetAt(
      params.position.line,
      params.position.character,
    );

    return provideDefinition(workspace, state, offset);
  });

  // ─── Completion ────────────────────────────────────────────

  connection.onCompletion((params) => {
    const state = workspace.get(params.textDocument.uri);
    if (!state) return [];

    const offset = state.lineMap.offsetAt(
      params.position.line,
      params.position.character,
    );

    return provideCompletion(workspace, state, offset);
  });

  // ─── Document Symbols ──────────────────────────────────────

  connection.onDocumentSymbol((params) => {
    const state = workspace.get(params.textDocument.uri);
    if (!state) return [];

    return provideDocumentSymbols(state);
  });

  // ─── Semantic Tokens ───────────────────────────────────────

  connection.languages.semanticTokens.on((params) => {
    const state = workspace.get(params.textDocument.uri);
    if (!state) return { data: [] };

    const data = provideSemanticTokens(state);
    return { data };
  });

  // ─── Start ─────────────────────────────────────────────────

  connection.listen();
}
