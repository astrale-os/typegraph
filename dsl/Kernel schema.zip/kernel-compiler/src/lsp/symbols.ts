// src/lsp/symbols.ts
// ============================================================
// Document Symbols — Outline / Breadcrumb / Symbol Search
// ============================================================

import {
  DocumentSymbol,
  SymbolKind,
  Range,
} from "vscode-languageserver-types";
import { DocumentState } from "./workspace.js";
import {
  Declaration,
  TypeAliasDecl,
  InterfaceDecl,
  ClassDecl,
  EdgeDecl,
  ExtendDecl,
  Attribute,
} from "../ast.js";

export function provideDocumentSymbols(state: DocumentState): DocumentSymbol[] {
  const ast = state.result.artifacts?.ast;
  if (!ast) return [];

  return ast.declarations.map((d) => declarationToSymbol(d, state)).filter(Boolean) as DocumentSymbol[];
}

function declarationToSymbol(decl: Declaration, state: DocumentState): DocumentSymbol | null {
  switch (decl.kind) {
    case "TypeAliasDecl":
      return typeAliasSymbol(decl, state);
    case "InterfaceDecl":
      return interfaceSymbol(decl, state);
    case "ClassDecl":
      return classSymbol(decl, state);
    case "EdgeDecl":
      return edgeSymbol(decl, state);
    case "ExtendDecl":
      return extendSymbol(decl, state);
    default:
      return null;
  }
}

function typeAliasSymbol(decl: TypeAliasDecl, state: DocumentState): DocumentSymbol {
  return {
    name: decl.name.value,
    detail: "type alias",
    kind: SymbolKind.TypeParameter,
    range: spanToRange(decl.span, state),
    selectionRange: spanToRange(decl.name.span, state),
  };
}

function interfaceSymbol(decl: InterfaceDecl, state: DocumentState): DocumentSymbol {
  const ext = decl.extends.length > 0
    ? `: ${decl.extends.map((e) => e.value).join(", ")}`
    : "";
  return {
    name: decl.name.value,
    detail: `interface${ext}`,
    kind: SymbolKind.Interface,
    range: spanToRange(decl.span, state),
    selectionRange: spanToRange(decl.name.span, state),
    children: decl.attributes.map((a) => attributeSymbol(a, state)),
  };
}

function classSymbol(decl: ClassDecl, state: DocumentState): DocumentSymbol {
  const impl = decl.implements.length > 0
    ? `: ${decl.implements.map((i) => i.value).join(", ")}`
    : "";
  return {
    name: decl.name.value,
    detail: `class${impl}`,
    kind: SymbolKind.Class,
    range: spanToRange(decl.span, state),
    selectionRange: spanToRange(decl.name.span, state),
    children: decl.attributes.map((a) => attributeSymbol(a, state)),
  };
}

function edgeSymbol(decl: EdgeDecl, state: DocumentState): DocumentSymbol {
  const params = decl.params
    .map((p) => `${p.name.value}`)
    .join(", ");
  return {
    name: decl.name.value,
    detail: `edge(${params})`,
    kind: SymbolKind.Event,
    range: spanToRange(decl.span, state),
    selectionRange: spanToRange(decl.name.span, state),
    children: decl.attributes.map((a) => attributeSymbol(a, state)),
  };
}

function extendSymbol(decl: ExtendDecl, state: DocumentState): DocumentSymbol {
  return {
    name: decl.uri,
    detail: `extend {${decl.imports.map((i) => i.value).join(", ")}}`,
    kind: SymbolKind.Module,
    range: spanToRange(decl.span, state),
    selectionRange: spanToRange(decl.span, state),
  };
}

function attributeSymbol(attr: Attribute, state: DocumentState): DocumentSymbol {
  return {
    name: attr.name.value,
    detail: formatTypeExpr(attr),
    kind: SymbolKind.Field,
    range: spanToRange(attr.span, state),
    selectionRange: spanToRange(attr.name.span, state),
  };
}

function formatTypeExpr(attr: Attribute): string {
  // Simple inline type rendering for the outline
  const nullable = attr.type.kind === "NullableType" ? "?" : "";
  switch (attr.type.kind) {
    case "NamedType":
      return `${(attr.type as any).name.value}${nullable}`;
    case "NullableType":
      return formatTypeExprInner((attr.type as any).inner) + "?";
    case "UnionType":
      return (attr.type as any).types.map((t: any) => formatTypeExprInner(t)).join(" | ");
    default:
      return "";
  }
}

function formatTypeExprInner(expr: any): string {
  if (!expr) return "";
  if (expr.kind === "NamedType") return expr.name.value;
  if (expr.kind === "NullableType") return formatTypeExprInner(expr.inner) + "?";
  if (expr.kind === "UnionType") return expr.types.map(formatTypeExprInner).join(" | ");
  if (expr.kind === "EdgeRefType") return expr.target ? `edge<${expr.target.value}>` : "edge<any>";
  return "";
}

function spanToRange(span: { start: number; end: number }, state: DocumentState): Range {
  const start = state.lineMap.positionAt(span.start);
  const end = state.lineMap.positionAt(span.end);
  return {
    start: { line: start.line, character: start.col },
    end: { line: end.line, character: end.col },
  };
}
