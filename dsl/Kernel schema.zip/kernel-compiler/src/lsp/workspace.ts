// src/lsp/workspace.ts
// ============================================================
// Workspace — Per-Document Compilation Cache
//
// Manages open documents, triggers recompilation on change,
// and exposes the latest compilation artifacts for all
// feature providers (hover, definition, completion, etc.)
// ============================================================

import { TextDocument } from "vscode-languageserver-textdocument";
import { Diagnostic as LspDiagnostic, DiagnosticSeverity } from "vscode-languageserver-types";
import { compile, CompileResult } from "../compile.js";
import { lex } from "../lexer.js";
import { parse } from "../parser.js";
import { lower } from "../lower.js";
import { resolve, createBuiltinScope, ResolvedSchema } from "../resolver.js";
import { validate } from "../validator.js";
import { KERNEL_SOURCE } from "../kernel.js";
import { DiagnosticBag, Diagnostic } from "../diagnostics.js";
import { LineMap } from "../linemap.js";
import { SchemaNode } from "../cst.js";
import { Schema as AstSchema, Declaration, EdgeDecl, ClassDecl, InterfaceDecl, TypeAliasDecl } from "../ast.js";
import { Symbol } from "../resolver.js";
import { Token, Span } from "../tokens.js";
import { isToken, isNode, CstChild, CstNode, spanOf } from "../cst.js";

export interface DocumentState {
  document: TextDocument;
  lineMap: LineMap;
  result: CompileResult;
  /** All tokens in source order, for offset-based lookup. */
  tokenIndex: Token[];
}

/** Cached kernel scope — built once, reused for all documents. */
let kernelScopeCache: Map<string, Symbol> | null = null;

function getKernelScope(): Map<string, Symbol> {
  if (kernelScopeCache) return kernelScopeCache;
  const bag = new DiagnosticBag();
  const builtins = createBuiltinScope();
  const { tokens } = lex(KERNEL_SOURCE, bag);
  const { cst } = parse(tokens, bag);
  const { ast } = lower(cst, bag);
  const { schema } = resolve(ast, builtins, bag);
  kernelScopeCache = schema.symbols;
  return kernelScopeCache;
}

/** Compile user source against cached kernel scope. */
function compileDocument(text: string): CompileResult {
  const diagnostics = new DiagnosticBag();
  const scope = getKernelScope();
  const { tokens } = lex(text, diagnostics);
  const { cst } = parse(tokens, diagnostics);
  const { ast } = lower(cst, diagnostics);
  const { schema: resolved } = resolve(ast, scope, diagnostics);
  validate(resolved, diagnostics);
  const hasErrors = diagnostics.hasErrors();

  return {
    ir: null, // LSP doesn't need IR
    diagnostics,
    artifacts: { cst, ast, resolved },
  };
}

export class Workspace {
  private documents = new Map<string, DocumentState>();

  /** Update or create document state. Returns LSP diagnostics. */
  update(uri: string, text: string, version: number): LspDiagnostic[] {
    const document = TextDocument.create(uri, "krl", version, text);
    const lineMap = new LineMap(text);
    const result = compileDocument(text);

    // Build token index from CST
    const tokenIndex: Token[] = [];
    if (result.artifacts?.cst) {
      collectTokens(result.artifacts.cst, tokenIndex);
      tokenIndex.sort((a, b) => a.span.start - b.span.start);
    }

    this.documents.set(uri, { document, lineMap, result, tokenIndex });

    return toLspDiagnostics(result.diagnostics, lineMap);
  }

  remove(uri: string): void {
    this.documents.delete(uri);
  }

  get(uri: string): DocumentState | undefined {
    return this.documents.get(uri);
  }

  /** Find the token at a given byte offset. */
  tokenAt(state: DocumentState, offset: number): Token | null {
    const tokens = state.tokenIndex;
    // Binary search
    let low = 0;
    let high = tokens.length - 1;
    while (low <= high) {
      const mid = (low + high) >> 1;
      const t = tokens[mid];
      if (offset < t.span.start) {
        high = mid - 1;
      } else if (offset >= t.span.end) {
        low = mid + 1;
      } else {
        return t;
      }
    }
    return null;
  }

  /** Find the symbol at a given byte offset (via reference map). */
  symbolAt(state: DocumentState, offset: number): Symbol | null {
    const token = this.tokenAt(state, offset);
    if (!token) return null;
    const resolved = state.result.artifacts?.resolved;
    if (!resolved) return null;

    // Check reference map (type references resolved during compilation)
    const ref = resolved.references.get(token.span.start);
    if (ref) return ref;

    // Check if the token itself is a declaration name
    const sym = resolved.symbols.get(token.text);
    if (sym && sym.span && sym.span.start === token.span.start) return sym;

    // Check if the token text matches a known symbol
    return resolved.symbols.get(token.text) ?? null;
  }

  /** Find the AST declaration for a given name. */
  declarationFor(state: DocumentState, name: string): Declaration | null {
    const resolved = state.result.artifacts?.resolved;
    if (!resolved) return null;
    const sym = resolved.symbols.get(name);
    return sym?.declaration ?? null;
  }
}

// ─── Helpers ─────────────────────────────────────────────────

function collectTokens(node: CstNode, out: Token[]): void {
  for (const child of node.children) {
    if (isToken(child)) {
      if (child.kind !== "EOF") {
        out.push(child);
      }
    } else if (isNode(child)) {
      collectTokens(child, out);
    }
  }
}

function toLspDiagnostics(bag: DiagnosticBag, lineMap: LineMap): LspDiagnostic[] {
  const result: LspDiagnostic[] = [];
  const all = [...bag.getErrors(), ...bag.getWarnings()];

  for (const diag of all) {
    const start = lineMap.positionAt(diag.span.start);
    const end = lineMap.positionAt(diag.span.end);

    result.push({
      range: {
        start: { line: start.line, character: start.col },
        end: { line: end.line, character: Math.max(end.col, start.col + 1) },
      },
      severity: diag.severity === "error"
        ? DiagnosticSeverity.Error
        : diag.severity === "warning"
          ? DiagnosticSeverity.Warning
          : DiagnosticSeverity.Information,
      code: diag.code,
      source: "krl",
      message: diag.message,
    });
  }

  return result;
}
