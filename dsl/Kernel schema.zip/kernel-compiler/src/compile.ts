// src/compile.ts
// ============================================================
// Compile — Full Pipeline
//
// Source → Lex → Parse → Lower → Resolve → Validate → Serialize
//
// This is the main entry point for the compiler. It handles
// the bootstrapping sequence (builtins → kernel → user code)
// and produces the IR JSON.
// ============================================================

import { lex } from "./lexer.js";
import { parse } from "./parser.js";
import { lower } from "./lower.js";
import { resolve, createBuiltinScope, ResolvedSchema } from "./resolver.js";
import { validate } from "./validator.js";
import { serialize, SerializeOptions } from "./serializer.js";
import { KERNEL_SOURCE } from "./kernel.js";
import { SchemaIR } from "./ir.js";
import { DiagnosticBag } from "./diagnostics.js";
import { SchemaNode } from "./cst.js";
import { Schema as AstSchema } from "./ast.js";

export interface CompileResult {
  /** The IR output. Null if there were errors preventing serialization. */
  ir: SchemaIR | null;
  diagnostics: DiagnosticBag;
  /** Intermediate artifacts for tooling (LSP, etc.) */
  artifacts: {
    cst: SchemaNode;
    ast: AstSchema;
    resolved: ResolvedSchema;
  } | null;
}

export interface CompileOptions extends SerializeOptions {
  /** Skip kernel prelude (for compiling the kernel itself). */
  skipKernel?: boolean;
}

/**
 * Compile a schema source string to IR.
 *
 * Bootstrapping sequence:
 *   1. Inject builtin scalars into empty scope
 *   2. Parse and resolve kernel.krl (unless skipKernel)
 *   3. Parse and resolve user source against primal scope
 *   4. Validate
 *   5. Serialize to IR
 */
export function compile(source: string, options?: CompileOptions): CompileResult {
  const diagnostics = new DiagnosticBag();

  // Step 0: Builtin scope
  let scope = createBuiltinScope();

  // Step 1-2: Bootstrap kernel (unless skipped)
  if (!options?.skipKernel) {
    const kernelResult = compilePhases(KERNEL_SOURCE, scope, diagnostics);
    if (!kernelResult || diagnostics.hasErrors()) {
      return { ir: null, diagnostics, artifacts: null };
    }
    scope = kernelResult.resolved.symbols;
  }

  // Step 3-5: Compile user source
  const result = compilePhases(source, scope, diagnostics);
  if (!result) {
    return { ir: null, diagnostics, artifacts: null };
  }

  // Validate
  validate(result.resolved, diagnostics);

  // Serialize (even if there are validation warnings)
  const ir = diagnostics.hasErrors()
    ? null
    : serialize(result.resolved, options);

  return {
    ir,
    diagnostics,
    artifacts: {
      cst: result.cst,
      ast: result.ast,
      resolved: result.resolved,
    },
  };
}

/** Run lex → parse → lower → resolve. Returns null on fatal parse errors. */
function compilePhases(
  source: string,
  baseScope: Map<string, any>,
  diagnostics: DiagnosticBag,
) {
  const { tokens } = lex(source, diagnostics);
  const { cst } = parse(tokens, diagnostics);
  const { ast } = lower(cst, diagnostics);
  const { schema: resolved } = resolve(ast, baseScope, diagnostics);

  return { cst, ast, resolved };
}
