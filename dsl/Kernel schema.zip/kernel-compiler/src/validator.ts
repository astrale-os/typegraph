// src/validator.ts
// ============================================================
// Validator — Resolved Schema → Validated Schema + Diagnostics
//
// Checks semantic rules that go beyond name resolution:
//   - Classes only implement interfaces (not other classes)
//   - Interfaces only extend interfaces
//   - Cardinality bounds are coherent (min <= max)
//   - no_self makes sense (endpoints share a type)
//   - Modifier placement is valid (e.g., acyclic on an edge, not a node)
//   - Default values match declared types
//   - No contradictory modifiers
// ============================================================

import {
  Declaration,
  InterfaceDecl,
  ClassDecl,
  EdgeDecl,
  TypeAliasDecl,
  Attribute,
  Modifier,
  CardinalityModifier,
  FlagModifier,
  LifecycleModifier,
  RangeModifier,
  LengthModifier,
  FormatModifier,
  InModifier,
  MatchModifier,
  IndexedModifier,
} from "./ast.js";
import { ResolvedSchema, Symbol } from "./resolver.js";
import { DiagnosticBag, DiagnosticCodes } from "./diagnostics.js";

export interface ValidateResult {
  valid: boolean;
  diagnostics: DiagnosticBag;
}

export function validate(
  schema: ResolvedSchema,
  diagnostics?: DiagnosticBag,
): ValidateResult {
  const bag = diagnostics ?? new DiagnosticBag();
  const v = new Validator(schema, bag);
  v.validate();
  return { valid: !bag.hasErrors(), diagnostics: bag };
}

// ─── Valid modifier kinds per context ────────────────────────

const EDGE_MODIFIERS = new Set([
  "FlagModifier",         // no_self, acyclic, unique, symmetric
  "CardinalityModifier",
  "LifecycleModifier",
]);

const EDGE_FLAGS = new Set(["no_self", "acyclic", "unique", "symmetric"]);

const ATTR_MODIFIERS = new Set([
  "FlagModifier",         // unique, readonly, indexed
  "IndexedModifier",      // indexed: asc|desc
]);

const ATTR_FLAGS = new Set(["unique", "readonly", "indexed"]);

const ALIAS_MODIFIERS = new Set([
  "FormatModifier",
  "MatchModifier",
  "InModifier",
  "LengthModifier",
  "RangeModifier",
]);

// ────────────────────────────────────────────────────────────

class Validator {
  private schema: ResolvedSchema;
  private diagnostics: DiagnosticBag;

  constructor(schema: ResolvedSchema, diagnostics: DiagnosticBag) {
    this.schema = schema;
    this.diagnostics = diagnostics;
  }

  validate(): void {
    for (const decl of this.schema.declarations) {
      switch (decl.kind) {
        case "TypeAliasDecl":
          this.validateTypeAlias(decl);
          break;
        case "InterfaceDecl":
          this.validateInterface(decl);
          break;
        case "ClassDecl":
          this.validateClass(decl);
          break;
        case "EdgeDecl":
          this.validateEdge(decl);
          break;
        case "ExtendDecl":
          // Nothing to validate beyond resolution
          break;
      }
    }
  }

  // ─── Type Alias ────────────────────────────────────────────

  private validateTypeAlias(decl: TypeAliasDecl): void {
    for (const mod of decl.modifiers) {
      if (!ALIAS_MODIFIERS.has(mod.kind)) {
        this.diagnostics.error(
          mod.span,
          DiagnosticCodes.V_INVALID_MODIFIER,
          `Modifier '${modifierName(mod)}' is not valid on a type alias`,
        );
      }
    }
  }

  // ─── Interface ─────────────────────────────────────────────

  private validateInterface(decl: InterfaceDecl): void {
    // Interfaces can only extend other interfaces
    for (const parent of decl.extends) {
      const sym = this.schema.symbols.get(parent.value);
      if (sym && sym.symbolKind !== "Interface") {
        this.diagnostics.error(
          parent.span,
          DiagnosticCodes.V_INTERFACE_IMPLEMENTS,
          `Interface '${decl.name.value}' can only extend interfaces, but '${parent.value}' is a ${sym.symbolKind}`,
        );
      }
    }

    for (const attr of decl.attributes) {
      this.validateAttribute(attr);
    }
  }

  // ─── Class ─────────────────────────────────────────────────

  private validateClass(decl: ClassDecl): void {
    // Classes can only implement interfaces
    for (const parent of decl.implements) {
      const sym = this.schema.symbols.get(parent.value);
      if (sym && sym.symbolKind !== "Interface") {
        this.diagnostics.error(
          parent.span,
          DiagnosticCodes.V_CLASS_EXTENDS_CLASS,
          `Class '${decl.name.value}' can only implement interfaces, but '${parent.value}' is a ${sym.symbolKind}`,
        );
      }
    }

    // Node classes shouldn't have edge modifiers
    for (const mod of decl.modifiers) {
      this.diagnostics.warning(
        mod.span,
        DiagnosticCodes.V_INVALID_MODIFIER,
        `Modifier '${modifierName(mod)}' on a node class has no effect`,
      );
    }

    for (const attr of decl.attributes) {
      this.validateAttribute(attr);
    }
  }

  // ─── Edge ──────────────────────────────────────────────────

  private validateEdge(decl: EdgeDecl): void {
    for (const mod of decl.modifiers) {
      this.validateEdgeModifier(mod, decl);
    }

    for (const attr of decl.attributes) {
      this.validateAttribute(attr);
    }
  }

  private validateEdgeModifier(mod: Modifier, decl: EdgeDecl): void {
    // Check modifier is valid in edge context
    if (!EDGE_MODIFIERS.has(mod.kind)) {
      this.diagnostics.error(
        mod.span,
        DiagnosticCodes.V_INVALID_MODIFIER,
        `Modifier '${modifierName(mod)}' is not valid on an edge`,
      );
      return;
    }

    // Flag validation
    if (mod.kind === "FlagModifier") {
      const flag = (mod as FlagModifier).flag;
      if (!EDGE_FLAGS.has(flag)) {
        this.diagnostics.error(
          mod.span,
          DiagnosticCodes.V_INVALID_MODIFIER,
          `Flag '${flag}' is not valid on an edge (valid: no_self, acyclic, unique, symmetric)`,
        );
      }
    }

    // Cardinality: check bounds and param name
    if (mod.kind === "CardinalityModifier") {
      const card = mod as CardinalityModifier;

      // Verify the parameter name exists in the edge signature
      const paramNames = decl.params.map((p) => p.name.value);
      if (!paramNames.includes(card.param.value)) {
        this.diagnostics.error(
          card.param.span,
          DiagnosticCodes.V_INVALID_CARDINALITY,
          `Cardinality references parameter '${card.param.value}', but edge '${decl.name.value}' has parameters: ${paramNames.join(", ")}`,
        );
      }

      // Check min <= max
      if (card.max !== null && card.min > card.max) {
        this.diagnostics.error(
          mod.span,
          DiagnosticCodes.V_INVALID_CARDINALITY,
          `Invalid cardinality: min (${card.min}) > max (${card.max})`,
        );
      }
    }
  }

  // ─── Attribute ─────────────────────────────────────────────

  private validateAttribute(attr: Attribute): void {
    for (const mod of attr.modifiers) {
      if (!ATTR_MODIFIERS.has(mod.kind)) {
        this.diagnostics.error(
          mod.span,
          DiagnosticCodes.V_INVALID_MODIFIER,
          `Modifier '${modifierName(mod)}' is not valid on an attribute`,
        );
      } else if (mod.kind === "FlagModifier") {
        const flag = (mod as FlagModifier).flag;
        if (!ATTR_FLAGS.has(flag)) {
          this.diagnostics.error(
            mod.span,
            DiagnosticCodes.V_INVALID_MODIFIER,
            `Flag '${flag}' is not valid on an attribute (valid: unique, readonly, indexed)`,
          );
        }
      }
    }
  }
}

// ─── Helpers ─────────────────────────────────────────────────

function modifierName(mod: Modifier): string {
  switch (mod.kind) {
    case "FlagModifier": return (mod as FlagModifier).flag;
    case "FormatModifier": return `format: ${(mod as FormatModifier).format}`;
    case "MatchModifier": return "match";
    case "InModifier": return "in";
    case "LengthModifier": return "length";
    case "IndexedModifier": return `indexed: ${(mod as IndexedModifier).direction}`;
    case "CardinalityModifier": return `${(mod as CardinalityModifier).param.value} -> ...`;
    case "RangeModifier": return (mod as RangeModifier).operator;
    case "LifecycleModifier": return (mod as LifecycleModifier).event;
    default: return "unknown";
  }
}
